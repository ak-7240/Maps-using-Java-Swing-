package waypoint;

public interface EventWayPoint {

    public void selected(MyWayPoint waypoint);
}